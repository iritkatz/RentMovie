﻿$(function () {
    $('.dropdown').hover(function () {
        $('.dropdown').toggleClass('open');
    })
});